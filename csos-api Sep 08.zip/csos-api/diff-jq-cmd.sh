diff <(jq -S . /tmp/csos-ui/csos-api.json) <(jq -S . csos-api.json)
